% Create a new Student object
student1 = Student('S12345', 'Alice Johnson', 20, 3.8, 'Computer Science');

% Display student information
student1.displayInfo();

% Update GPA
student1 = student1.updateGPA(3.9);